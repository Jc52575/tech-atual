# Achadinhos Atual
Portal de achadinhos, ofertas, listas de melhores produtos e recomendações.

## Publicação
Projeto estático para GitHub Pages.

## Afiliados
O link do Kit Revlon usa o link de afiliada fornecido pela proprietária do projeto. Outros botões são buscas provisórias e devem ser substituídos por links personalizados de afiliada quando forem gerados.
